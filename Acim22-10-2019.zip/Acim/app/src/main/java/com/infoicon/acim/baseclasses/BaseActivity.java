package com.infoicon.acim.baseclasses;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by sumit on 11/8/17.
 */

public abstract class BaseActivity extends AppCompatActivity {


            public abstract void initViews();

            public abstract void initListeners();
}
