package com.infoicon.acim.interfaces;

import android.view.View;

/**
 * Created by sumit on 18/8/17.
 */

public interface RecyclerViewClickListener {

    public void recyclerViewListClicked(View v, int position);
}
