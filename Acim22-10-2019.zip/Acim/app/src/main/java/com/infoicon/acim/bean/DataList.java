package com.infoicon.acim.bean;

public class DataList {
}
