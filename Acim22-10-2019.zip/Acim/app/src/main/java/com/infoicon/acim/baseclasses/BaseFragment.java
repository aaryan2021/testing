package com.infoicon.acim.baseclasses;

import android.support.v4.app.Fragment;

/**
 * Created by sumit on 16/8/17.
 */

public abstract class BaseFragment extends Fragment {

    public abstract void initViews();

    public abstract void initListeners();
}
