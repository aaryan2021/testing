package com.infoicon.acim.utils.interfaces;

import android.view.View;

import com.infoicon.acim.manual.ManualFragment;

/**
 * Created by sumit on 18/8/17.
 */

public interface RecyclerViewClickListener {

    public void recyclerViewListClicked(View v, int position);
}
