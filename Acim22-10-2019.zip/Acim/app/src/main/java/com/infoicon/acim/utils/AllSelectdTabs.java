package com.infoicon.acim.utils;

/**
 * Created by sumit on 16/8/17.
 */

public class AllSelectdTabs {
    String selectedTabs;

    public void setSelectedTabs(String selectedTabs) {
        this.selectedTabs = selectedTabs;
    }

    public String getSelectedTabs() {
        return selectedTabs;
    }
}
