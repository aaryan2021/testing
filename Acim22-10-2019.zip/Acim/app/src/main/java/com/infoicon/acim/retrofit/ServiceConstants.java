package com.infoicon.acim.retrofit;

/**
 * Created by infoicon on 13/4/17.
 */

public class ServiceConstants {
    public static final String APP_AUTHENTICATION_KEY = "AUTH_KEY";
    public static final long READ_TIMEOUT = 30;
    public static final long CONNECT_TIMEOUT = 30;
    public static final String USER = "USER";
    public static String ERROR_CODE ="";
}
