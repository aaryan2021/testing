package com.infoicon.acim.utils;

/**
 * Created by sumit on 12/9/17.
 */

public interface HomeMenuItemClickListener {


    public void onHomeMenuItemClick(int pos);


}
